import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

data = {
    'Provider': ['A (Amazon)', 'B (Microsoft)', 'C (Google)', 'D (Alibaba)', 'E (Others)'],
    'Market_Share_Pct': [31.5, 24.0, 9.8, 8.5, 26.2]
}

df = pd.DataFrame(data)

# Pie chart without shadow or exploded slices
plt.figure(figsize=(10, 7))
plt.pie(df['Market_Share_Pct'], labels=df['Provider'], autopct='%1.1f%%', startangle=140)

# Set title
plt.title('Market Share Distribution by Provider')

plt.show()
