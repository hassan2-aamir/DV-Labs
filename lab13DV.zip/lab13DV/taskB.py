import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler

data = {
    'Month': ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'],
    'Ice_Cream_Sales': [2500, 3100, 4500, 5500, 7500, 9500, 11500, 12000, 8800, 8500],
    'Avg_Temp_C': [13.3, 15.1, 18.2, 21.1, 22.8, 19.9, 25.5, 22.8, 19.1, 14.5]
}

df = pd.DataFrame(data)

# Normalize both Ice Cream Sales and Average Temperature
scaler = MinMaxScaler()

# Reshape data to make it 2D (required for MinMaxScaler)
df[['Ice_Cream_Sales_Normalized', 'Avg_Temp_C_Normalized']] = scaler.fit_transform(
    df[['Ice_Cream_Sales', 'Avg_Temp_C']])

fig, ax1 = plt.subplots(figsize=(10, 6))

# Plot Ice Cream Sales (normalized)
ax1.plot(df['Month'], df['Ice_Cream_Sales_Normalized'], color='tab:blue', marker='o', label='Ice Cream Sales')
ax1.set_xlabel('Month')
ax1.set_ylabel('Ice Cream Sales (Normalized)', color='tab:blue')
ax1.tick_params(axis='y', labelcolor='tab:blue')

# Create a second y-axis for the Average Temperature (normalized)
ax2 = ax1.twinx()
ax2.plot(df['Month'], df['Avg_Temp_C_Normalized'], color='tab:red', marker='s', label='Average Temperature')
ax2.set_ylabel('Average Temperature (Normalized)', color='tab:red')
ax2.tick_params(axis='y', labelcolor='tab:red')

# Title and layout adjustments
plt.title('Normalized Ice Cream Sales and Average Temperature (Monthly Data)')
plt.show()
