import matplotlib.pyplot as plt
import numpy as np

years = np.arange(2000, 2021)
groups = ['Men 18-25', 'Women 18-25', 'Men 26+', 'Women 26+']
np.random.seed(42)
data = [
    np.cumsum(np.random.normal(0, 0.5, 21)) + 5,
    np.cumsum(np.random.normal(0, 0.4, 21)) + 6,
    np.cumsum(np.random.normal(0, 0.3, 21)) + 3,
    np.cumsum(np.random.normal(0, 0.2, 21)) + 4
]

plt.figure(figsize=(10, 6))

# Update code to add line styles and markers for accessibility
styles = ['-', '--', '-.', ':']  # Different line styles for each group
markers = ['o', 's', '^', 'D']  # Different markers for each group

for i, group in enumerate(groups):
    plt.plot(years, data[i], label=group, linestyle=styles[i], marker=markers[i], linewidth=2, alpha=0.7)

# Add labels and larger text size for better accessibility
plt.title('Unemployment Rates by Demographic Group (2000-2020)', fontsize=16)
plt.xlabel('Year', fontsize=14)
plt.ylabel('Unemployment Rate (%)', fontsize=14)
plt.legend(loc='upper right', fontsize=12)
plt.grid(True, alpha=0.4, color='gray')

plt.show()
