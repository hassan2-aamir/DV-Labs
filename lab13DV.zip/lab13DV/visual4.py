import matplotlib.pyplot as plt
import numpy as np

np.random.seed(0)
data = np.random.rand(10, 10) * 50

plt.figure(figsize=(8, 7))

# Use a more accessible colormap
plt.imshow(data, cmap='viridis', origin='lower', interpolation='nearest')

# Add colorbar with clearer labeling
plt.colorbar(label='Temperature Anomaly (°C)')

# Improve axis labeling and increase font size
plt.xlabel('Longitude', fontsize=14)
plt.ylabel('Latitude', fontsize=14)
plt.show()
