import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

dates = pd.to_datetime(pd.date_range('2023-01-01', periods=50, freq='W'))
values = np.sin(np.arange(50) * 0.5) * 10 + 20

plt.figure(figsize=(9, 4))
plt.plot(dates, values)

# Update axis labels and font size
plt.xticks(dates[::5], [d.strftime('%b %d') for d in dates[::5]], rotation=45, ha='right', fontsize=12)
plt.xlabel('Date (Weekly Samples)', fontsize=14)
plt.ylabel('Index Value', fontsize=14)

# Add a description for accessibility
plt.title('Index Value over Weekly Samples (2023)', fontsize=16)

plt.tight_layout()
plt.show()
