import matplotlib.pyplot as plt
import numpy as np

categories = ['Q1', 'Q2', 'Q3', 'Q4']
values = [55, 62, 78, 91]
HIGH_CONTRAST_COLOR = '#000000' 

plt.figure(figsize=(8, 5))
bars = plt.bar(categories, values, color='#4682B4')

# Update text labels with higher contrast
plt.xlabel('Quarter', color=HIGH_CONTRAST_COLOR, fontsize=14)
plt.ylabel('Revenue (Millions)', color=HIGH_CONTRAST_COLOR, fontsize=14)
plt.xticks(color=HIGH_CONTRAST_COLOR, fontsize=12)
plt.yticks(color=HIGH_CONTRAST_COLOR, fontsize=12)

# Add labels to bars for color-blind users
for i, v in enumerate(values):
    plt.text(i, v + 2, str(v), ha='center', color=HIGH_CONTRAST_COLOR, fontsize=12)

ax = plt.gca()
for spine in ax.spines.values():
    spine.set_color(HIGH_CONTRAST_COLOR)

# Add better contrast grid lines
plt.grid(True, linestyle='--', alpha=0.5, color=HIGH_CONTRAST_COLOR)

plt.show()
