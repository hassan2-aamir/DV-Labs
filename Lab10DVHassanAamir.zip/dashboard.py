# Import Required Libraries
import streamlit as st
import pandas as pd
import altair as alt

# Set page configuration
st.set_page_config(page_title="Gapminder Dashboard", layout="wide")

# Title
st.title("Gapminder Dashboard")
st.markdown("---")

# Load data
df = pd.read_csv('gapminder - gapminder.csv', index_col=0)

# 1. Bar Chart - Continent-Wise Comparison
st.subheader("1. Continent-Wise Comparison")

# Aggregate data by continent
continent_stats = df.groupby('continent').agg({
    'population': 'sum',
    'gdp_cap': 'mean',
    'life_exp': 'mean'
}).reset_index()

# Create tabs for different metrics
tab1, tab2, tab3 = st.tabs(["Population", "GDP per Capita", "Life Expectancy"])

with tab1:
    # simple Plotly figure dict for population by continent
    palette = ['#636EFA', '#EF553B', '#00CC96', '#AB63FA', '#FFA15A', '#19D3F3']
    colors = [palette[i % len(palette)] for i in range(len(continent_stats))]
    fig_pop = {
        'data': [
            {
                'type': 'bar',
                'x': continent_stats['continent'].tolist(),
                'y': continent_stats['population'].tolist(),
                'marker': {'color': colors},
                'text': continent_stats['population'].tolist(),
                'textposition': 'outside'
            }
        ],
        'layout': {
            'title': 'Total Population by Continent',
            'showlegend': False,
            'height': 500,
            'xaxis': {'title': 'Continent'},
            'yaxis': {'title': 'Total Population'}
        }
    }
    st.plotly_chart(fig_pop, use_container_width=True)

with tab2:
    # simple Plotly figure dict for average GDP per capita by continent
    colors = [palette[i % len(palette)] for i in range(len(continent_stats))]
    fig_gdp = {
        'data': [
            {
                'type': 'bar',
                'x': continent_stats['continent'].tolist(),
                'y': continent_stats['gdp_cap'].tolist(),
                'marker': {'color': colors},
                'text': [f"{v:.2f}" for v in continent_stats['gdp_cap'].tolist()],
                'textposition': 'outside'
            }
        ],
        'layout': {
            'title': 'Average GDP per Capita by Continent',
            'showlegend': False,
            'height': 500,
            'xaxis': {'title': 'Continent'},
            'yaxis': {'title': 'Average GDP per Capita'}
        }
    }
    st.plotly_chart(fig_gdp, use_container_width=True)

with tab3:
    # simple Plotly figure dict for average life expectancy by continent
    colors = [palette[i % len(palette)] for i in range(len(continent_stats))]
    fig_life = {
        'data': [
            {
                'type': 'bar',
                'x': continent_stats['continent'].tolist(),
                'y': continent_stats['life_exp'].tolist(),
                'marker': {'color': colors},
                'text': [f"{v:.2f}" for v in continent_stats['life_exp'].tolist()],
                'textposition': 'outside'
            }
        ],
        'layout': {
            'title': 'Average Life Expectancy by Continent',
            'showlegend': False,
            'height': 500,
            'xaxis': {'title': 'Continent'},
            'yaxis': {'title': 'Average Life Expectancy (years)'}
        }
    }
    st.plotly_chart(fig_life, use_container_width=True)

st.markdown("---")

# 2. Scatter Plot - GDP per Capita vs Life Expectancy
st.subheader("2. GDP per Capita vs Life Expectancy")

# Create Altair scatter plot
scatter = alt.Chart(df).mark_circle(size=100).encode(
    x=alt.X('gdp_cap:Q', 
            title='GDP per Capita',
            scale=alt.Scale(type='log')),
    y=alt.Y('life_exp:Q', 
            title='Life Expectancy (years)'),
    color=alt.Color('continent:N', 
                    title='Continent'),
    size=alt.Size('population:Q', 
                  title='Population',
                  scale=alt.Scale(range=[50, 1000])),
    tooltip=['country', 'continent', 'gdp_cap', 'life_exp', 'population']
).properties(
    width=800,
    height=500,
    title='Relationship between GDP per Capita and Life Expectancy'
).interactive()

st.altair_chart(scatter, use_container_width=True)

st.markdown("---")

# 3. Line Chart - Population Trend by Continent
st.subheader("3. Population Trend by Continent")

# Load full dataset with historical data
@st.cache_data
def load_full_data():
    df_full = pd.read_csv('gapminder_full.csv')
    return df_full

df_full = load_full_data()

# Aggregate population by continent and year
continent_year_pop = df_full.groupby(['continent', 'year'])['population'].sum().reset_index()

# Create line chart showing population trends over time using plain Plotly traces
traces = []
conts = continent_year_pop['continent'].unique().tolist()
for i, cont in enumerate(conts):
    dfc = continent_year_pop[continent_year_pop['continent'] == cont].sort_values('year')
    traces.append({
        'type': 'scatter',
        'mode': 'lines+markers',
        'x': dfc['year'].tolist(),
        'y': dfc['population'].tolist(),
        'name': cont,
        'marker': {'size': 6},
        'line': {'width': 3, 'color': palette[i % len(palette)]}
    })

fig_line = {
    'data': traces,
    'layout': {
        'title': 'Population Trend by Continent (1952-2007)',
        'height': 500,
        'hovermode': 'x unified',
        'xaxis': {'title': 'Year'},
        'yaxis': {'title': 'Total Population'},
        'legend': {
            'orientation': 'v',
            'yanchor': 'top',
            'y': 1,
            'xanchor': 'left',
            'x': 1.02
        }
    }
}

st.plotly_chart(fig_line, use_container_width=True)
